1. Files
1) nlpcc2016-word-seg-train.dat
		the training files
2) nlpcc2016-word-seg-test.dat
		the test files
3) nlpcc2016-word-seg-dev.dat
		the develop files
4) background.txt
		the background data, from which the training and test data are drawn. The purpose is to find the more sophisticated features by the unsupervised way.


